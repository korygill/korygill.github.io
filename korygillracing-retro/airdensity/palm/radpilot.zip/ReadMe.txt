
RAD v1.0 - Relative Air Density Calculator

Hello,

Here's a small Palm Pilot (OS version 2.0 or greater) application to 
calculate relative air density from temperature, humidity and barometric 
pressure. You can then use this to help you jet your 2-stroke racer (or 
whatever else would be applicable). It currently accepts the temp in 
fahrenheit and the pressure in inches of mercury. A future version will allow 
for celcius temperature entry (although there's no current plan for a future 
version). Just enter the three values and hit the 'Calculate' button - what 
could be easier!?

RAD was written by Stephen Bacon based upon calculations developed by Kory Gill
(which means he did all the hard work) and is free for you to have / use / give
away. However I in no way guarantee its accuracy or functionality so don't sue
me if your bike siezes up and you highside (I of course have great faith in it 
having tested its results vs. Kory's, but being this is the U.S., and people 
sue over anything they can, I wanted to put this disclaimer in).

The app is written in CASL - the Compact Application Solution Language, which
is a product of Feras Information Technologies . Basically it's a device 
independent language that'll allow an author to write a single app for
multiple platforms (same idea as Java).

What this means is that the app is actually distributed as "byte code" (rather
that machine code), and so requires a "run-time interpreter" to actually do
its thing. The CASL interpreter for the Palm OS is included and must be 
installed onto you Pilot to allow RAD to run.

In addition, calculating the air density requires the use of a "math library"
to perform some calculations. The math library used is "mathlib.prc" - which
was written by Rick Heubner, and falls under the "GNU General Public License".
Mathlib.prc is freely available with full source code and documentation at the 
MathLib Information web page at www.probe.net/~rhuebner/mathlib.html.
Under the GNU license I must not charge you for it (I'm not, as RAD is itself
free), and provide you with the source code, etc. which is in this zip file.

By now you're probably thinking, "How much space does this take up?" Well,
RAD itself takes only 4K. The CASL runtime and mathlib take up 92K (42K + 50K).
Yikes! So that's the bad thing, the good thing is that many apps use / need 
mathlib, so you may already be using it (or soon will). Because all these apps 
share the single copy of mathlib, it actually saves space in the long run 
(because all these apps don't need to each know 18K worth of math calculations)
CASL programs are a different story. I have no idea what the chances are that 
you have / will have another CASL-based app so I can only offer this 
condolence: Feras is working on a version that will not require the run-time, 
but the result is that RAD itself will become bigger. When this becomes 
possible I will offer RAD in a fully compiled version. Hopefully this version 
will occupy less than 4K + 42K. When depends upon Feras, so I can't give a date.


So, it boils down to installing (via the PalmPilot install tool) the following:
	RAD.prc
	CASLrt_pro.prc
	MathLib.prc

The rest of the files in the zip are informational, etc. and do not need to be 
put on your Pilot.

Contacts:

   for problems, enhancement requests, large gifts of $$$ please send email to:
         rad@stevebacon.org

   for DOS, Mac and other versions of RAD calculators, plus a lot of info 
   regarding weather calculations visit Kory Gill's web site at:
         http://www.nwlink.com/~koryg/

   for information on the CASL development environment contact:
         Feras Information Technologies 
         315 Delaware Avenue
         Lansdale  PA  19446
         Phone 215-362-8109 o Fax 215-361-3523
         http://www.caslsoft.com


   for information on mathlib visit:
         http://www.probe.net/~rhuebner/mathlib.html

   for information on the Free Software Foundation / GNU visit:
         http://www.fsf.org or
	 http://www.gnu.org

-Steve

p.s. This is version 1.0 of ReadMe.txt

